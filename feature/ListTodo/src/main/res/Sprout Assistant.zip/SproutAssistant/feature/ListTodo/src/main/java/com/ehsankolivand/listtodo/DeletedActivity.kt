package com.ehsankolivand.listtodo

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.ehsankolivand.listtodo.menu.favorite.FavoriteFragment
import com.ehsankolivand.listtodo.menu.home.HomeFragment
import com.ehsankolivand.listtodo.menu.profile.ProfileFragment
import com.google.android.material.navigation.NavigationView
import dagger.hilt.android.AndroidEntryPoint
import nl.joery.animatedbottombar.AnimatedBottomBar
import nl.joery.animatedbottombar.AnimatedBottomBar.OnTabSelectListener
import java.util.*

@AndroidEntryPoint
class DeletedActivity : AppCompatActivity() {
    private lateinit var toolbar: Toolbar
    private lateinit var animatedBottomBar: AnimatedBottomBar
    lateinit var fragmentManager: FragmentManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setToolbar()
        initViews(savedInstanceState)
        initComponentsNavHeader()
    }

    private fun setToolbar() {
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        Objects.requireNonNull(supportActionBar)?.setTitle(0)
    }

    @SuppressLint("NonConstantResourceId")
    private fun initViews(savedInstanceState: Bundle?) {
        /**
         * Menu Bottom Navigation Drawer
         */
        animatedBottomBar = findViewById(R.id.navigation)
        if (savedInstanceState == null) {
            animatedBottomBar.selectTabById(R.id.nav_menu_home, true)
            fragmentManager = supportFragmentManager
            val homeFragment = HomeFragment()
            fragmentManager.beginTransaction().replace(R.id.fragment_container, homeFragment)
                .commit()
        }
        animatedBottomBar.setOnTabSelectListener(object : OnTabSelectListener {
            override fun onTabSelected(
                lastIndex: Int,
                lastTab: AnimatedBottomBar.Tab?,
                newIndex: Int,
                newTab: AnimatedBottomBar.Tab
            ) {
                var fragment: Fragment? = null
                when (newTab.id) {
                    R.id.nav_menu_home -> fragment = HomeFragment()
                    R.id.nav_menu_wishlist -> fragment = FavoriteFragment()
                    R.id.nav_menu_signin -> fragment = ProfileFragment()
                }
                if (fragment != null) {
                    fragmentManager = supportFragmentManager
                    fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment)
                        .commit()
                } else {
                    Log.e(TAG, "Error in creating Fragment")
                }
            }
        })
        /**
         * Menu Navigation Drawer
         */
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer.addDrawerListener(toggle)
        toggle.isDrawerIndicatorEnabled = false
        toggle.toolbarNavigationClickListener = View.OnClickListener {
            drawer.openDrawer(
                GravityCompat.START
            )
        }
        toggle.setHomeAsUpIndicator(R.drawable.ic_drawer)
        toggle.syncState()
    }

    private fun initComponentsNavHeader() {
        val navigationView = findViewById<NavigationView>(R.id.nav_view)
        //        navigationView.setItemIconTintList(null); //disable tint on each icon to use color icon svg
        navigationView.setNavigationItemSelectedListener(object :
            NavigationView.OnNavigationItemSelectedListener {
            @SuppressLint("NonConstantResourceId")
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                when (item.itemId) {
                    R.id.nav_weeds -> Pesan("Menu Weeds")
                    R.id.nav_insects -> Pesan("Menu Insects")
                    R.id.nav_diseases -> Pesan("Menu Diseases")
                    R.id.nav_products -> Pesan("Menu Products")
                    R.id.nav_help -> Pesan("Menu Help")
                }
                val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
                drawer.closeDrawer(GravityCompat.START)
                return true
            }

            private fun Pesan(pesan: String) {
                Toast.makeText(this@DeletedActivity, pesan, Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onBackPressed() {
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    companion object {
        private val TAG = DeletedActivity::class.java.simpleName
    }
}