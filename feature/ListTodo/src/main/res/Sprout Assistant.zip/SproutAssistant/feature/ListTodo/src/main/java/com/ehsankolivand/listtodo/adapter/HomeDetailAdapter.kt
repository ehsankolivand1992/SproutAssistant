package com.ehsankolivand.listtodo.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.viewpager.widget.PagerAdapter
import com.ehsankolivand.listtodo.R

class HomeDetailAdapter(
    var context: Context,
    var inflater: LayoutInflater,
    private val imagesList: List<Int>
) :
    PagerAdapter() {
    private var ivDetailImagesProduct: ImageView? = null
    override fun getCount(): Int {
        return imagesList.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view: View = inflater.inflate(R.layout.slide_images_detail_product, container, false)
        setViews(view)
        initViews(position)
        container.addView(view)
        return view
    }

    //set view
    private fun setViews(view: View) {
        ivDetailImagesProduct = view.findViewById(R.id.iv_images_detail_product)
    }

    //set init
    private fun initViews(position: Int) {
        val images = imagesList[position]
        ivDetailImagesProduct!!.setBackgroundResource(images)

//        Glide.with(context)
//                .load(images)
//                .diskCacheStrategy(DiskCacheStrategy.ALL)
//                .skipMemoryCache(true)
//                .into(ivDetailImagesProduct);
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as LinearLayout)
    }

    override fun getItemPosition(`object`: Any): Int {
        return super.getItemPosition(`object`)
    }
}
