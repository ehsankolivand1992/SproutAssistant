package com.ehsankolivand.listtodo.menu.home

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R
import com.ehsankolivand.listtodo.adapter.GroupAdapter
import com.ehsankolivand.listtodo.model.Group
import com.ehsankolivand.listtodo.model.Plant
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList
@AndroidEntryPoint
class HomeFragment : Fragment() {
    private lateinit var mContext: Context
    private lateinit var recyclerView: RecyclerView
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var groups: ArrayList<Group>
    private lateinit var featured_plants: ArrayList<Plant>
    private lateinit var recommended: ArrayList<Plant>

    //todo 0. If you want to add more types of objects, you can easily do so. Check "todo list" (I added it step by step)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setAdapterType(view)
        setAdapter()
    }

    private fun initGroupData() {
        groups = ArrayList()
        groups!!.add(Group("Recommended", "More"))
        groups!!.add(Group("Featured Plants", "More"))
    }

    private fun initPlantData() {
        featured_plants = ArrayList()
        recommended = ArrayList()
        featured_plants!!.add(
            Plant(
                "Colorado Columbines",
                "Indonesia",
                "$300",
                R.drawable.bottom_img_1
            )
        )
        featured_plants!!.add(Plant("Common Mallows", "Russia", "$200", R.drawable.bottom_img_1))
        featured_plants!!.add(Plant("Cherry Blossom", "Italy", "$100", R.drawable.bottom_img_1))
        recommended!!.add(Plant("Aquilegia", "Indonesia", "$600", R.drawable.image_1))
        recommended!!.add(Plant("Angelica", "Russia", "$500", R.drawable.image_2))
        recommended!!.add(Plant("Camellia", "Italy", "$400", R.drawable.image_3))
        recommended!!.add(Plant("Narcissa", "France", "$300", R.drawable.image_1))
        recommended!!.add(Plant("Orchid", "China", "$200", R.drawable.image_2))
        recommended!!.add(Plant("Lily", "America", "$100", R.drawable.image_3))
    }

    private fun setAdapterType(view: View) {
        recyclerView = view.findViewById(R.id.recyclerView)
        layoutManager = LinearLayoutManager(mContext)
        recyclerView.setLayoutManager(layoutManager)
    }

    private fun setAdapter() {
        initGroupData()
        initPlantData()
        //todo 1. Add the new object to the parameter list.
        groupAdapter = GroupAdapter(mContext!!, groups!!, featured_plants!!, recommended!!)
        recyclerView!!.adapter = groupAdapter
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }
}