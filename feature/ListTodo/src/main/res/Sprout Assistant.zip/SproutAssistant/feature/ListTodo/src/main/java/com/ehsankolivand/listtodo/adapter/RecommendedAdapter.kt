package com.ehsankolivand.listtodo.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R
import com.ehsankolivand.listtodo.menu.home.HomeDetailActivity
import com.ehsankolivand.listtodo.model.Plant
import com.ehsankolivand.listtodo.viewholder.RecommendedViewHolder
import java.util.ArrayList

class RecommendedAdapter(private val context: Context, plants: ArrayList<Plant>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder?>() {
    private val plants: ArrayList<Plant>
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.recommended_item, parent, false)
        return RecommendedViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        setImage(
            (holder as RecommendedViewHolder).recommended_picture,
            plants[position].plantPicture
        )
        plants[position].plantTitle?.let {
            setTitle(
                (holder as RecommendedViewHolder).recommended_title,
                it
            )
        }
        plants[position].plantCountry?.let {
            setCountry(
                (holder as RecommendedViewHolder).recommended_country,
                it
            )
        }
        plants[position].plantPrice?.let {
            setPrice(
                (holder as RecommendedViewHolder).recommended_price,
                it
            )
        }
        setOnClick((holder as RecommendedViewHolder).recommended_parent)
    }

    private fun setImage(imageView: ImageView, image: Int) {
        imageView.setBackgroundResource(image)

//        Picasso.get().load(imageURL).fit().centerCrop().into(imageView, new Callback() {
//            @Override
//            public void onSuccess() {
//
//            }
//
//            @Override
//            public void onError(Exception e) {
//                imageView.setBackgroundResource(R.drawable.ic_launcher_background);
//            }
//        });
    }

    private fun setTitle(textView: TextView, plantTitle: String) {
        textView.text = plantTitle
    }

    private fun setCountry(textView: TextView, plantCountry: String) {
        textView.text = plantCountry
    }

    private fun setPrice(textView: TextView, plantPrice: String) {
        textView.text = plantPrice
    }

    private fun setOnClick(button: RelativeLayout) {
        button.setOnClickListener { view: View? ->
            context.startActivity(
                Intent(
                    context,
                    HomeDetailActivity::class.java
                )
            )
        }
    }

    override fun getItemCount(): Int {
        return plants.size
    }

    init {
        this.plants = plants
    }
}
