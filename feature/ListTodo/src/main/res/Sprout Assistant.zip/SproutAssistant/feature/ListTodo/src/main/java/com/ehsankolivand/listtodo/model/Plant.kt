package com.ehsankolivand.listtodo.model

class Plant {
    var plantTitle: String? = null
    var plantCountry: String? = null
    var plantPrice: String? = null
    var plantPicture = 0

    constructor(
        plantTitle: String?,
        plantCountry: String?,
        plantPrice: String?,
        plantPicture: Int
    ) {
        this.plantTitle = plantTitle
        this.plantCountry = plantCountry
        this.plantPrice = plantPrice
        this.plantPicture = plantPicture
    }

    constructor() {}
}
