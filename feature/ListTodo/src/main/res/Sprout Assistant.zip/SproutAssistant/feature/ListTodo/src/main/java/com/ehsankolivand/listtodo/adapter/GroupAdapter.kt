package com.ehsankolivand.listtodo.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R
import com.ehsankolivand.listtodo.model.Group
import com.ehsankolivand.listtodo.model.Plant
import com.ehsankolivand.listtodo.viewholder.GroupViewHolder
import java.util.ArrayList

class GroupAdapter(
    private val context: Context,
    groups: ArrayList<Group>,
    featured_plants: ArrayList<Plant>,
    recommended: ArrayList<Plant>
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder?>() {
    private val groups: ArrayList<Group>
    private val featured_plants: ArrayList<Plant>
    private val recommended: ArrayList<Plant>
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.group_item, parent, false)
        return GroupViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        groups[position].groupTitle?.let {
            setGroupTitle((holder as GroupViewHolder).group_title,
                it
            )
        }
        groups[position].groupButtonTitle?.let {
            setGroupButtonTitle(
                (holder as GroupViewHolder).view_all,
                it
            )
        }
        groups[position].groupTitle?.let {
            setOnClickViewAll((holder as GroupViewHolder).head_parent,
                it
            )
        }
        setLists((holder as GroupViewHolder).group_recycler_view, position)
    }

    override fun getItemCount(): Int {
        return groups.size
    }

    private fun setGroupTitle(textView: TextView, text: String) {
        textView.text = text
    }

    private fun setGroupButtonTitle(button: Button, text: String) {
        button.text = text
    }

    private fun setOnClickViewAll(button: RelativeLayout, groupTitle: String) {
        button.setOnClickListener {
            Toast.makeText(
                context,
                "View all $groupTitle",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun setLists(recyclerView: RecyclerView, position: Int) {
        //todo 4. Create a new adapter for it and display it in the list
        when (position) {
            0 -> setRecommendedList(recyclerView)
            1 -> setFeaturedPlantsList(recyclerView)
        }
    }

    private fun setFeaturedPlantsList(recyclerView: RecyclerView) {
        val featuredPlantsAdapter = FeaturedPlantsAdapter(context, featured_plants)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = featuredPlantsAdapter
        recyclerView.isNestedScrollingEnabled = true
    }

    private fun setRecommendedList(recyclerView: RecyclerView) {
        val simpleAdapter = RecommendedAdapter(context, recommended)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.adapter = simpleAdapter
        recyclerView.isNestedScrollingEnabled = true
    }

    //todo 2. Create a new list with the new object
    init {
        //todo 3. Add it to the constructor
        this.groups = groups
        this.featured_plants = featured_plants
        this.recommended = recommended
    }
}

