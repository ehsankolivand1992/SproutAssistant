package com.ehsankolivand.listtodo.viewholder

import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R


class RecommendedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    var recommended_picture: ImageView
    var recommended_parent: RelativeLayout
    var recommended_title: TextView
    var recommended_country: TextView
    var recommended_price: TextView

    init {
        recommended_picture = itemView.findViewById(R.id.item_recommended_picture)
        recommended_parent = itemView.findViewById(R.id.item_recommended_parent)
        recommended_title = itemView.findViewById(R.id.item_recommended_title)
        recommended_price = itemView.findViewById(R.id.item_recommended_price)
        recommended_country = itemView.findViewById(R.id.item_recommended_country)
    }
}