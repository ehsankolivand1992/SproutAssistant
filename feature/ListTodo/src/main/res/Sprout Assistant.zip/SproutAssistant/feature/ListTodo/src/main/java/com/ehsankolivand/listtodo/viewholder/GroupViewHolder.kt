package com.ehsankolivand.listtodo.viewholder

import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R

class GroupViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    var head_parent: RelativeLayout
    var group_title: TextView
    var view_all: Button
    var group_recycler_view: RecyclerView

    init {
        head_parent = itemView.findViewById(R.id.head_parent)
        group_title = itemView.findViewById(R.id.group_title)
        view_all = itemView.findViewById(R.id.view_all)
        group_recycler_view = itemView.findViewById(R.id.group_recycler_view)
    }
}
