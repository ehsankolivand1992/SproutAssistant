package com.ehsankolivand.listtodo.model

class Group {
    var groupTitle: String? = null
    var groupButtonTitle: String? = null

    constructor() {}
    constructor(groupTitle: String?, groupButtonTitle: String?) {
        this.groupTitle = groupTitle
        this.groupButtonTitle = groupButtonTitle
    }
}
