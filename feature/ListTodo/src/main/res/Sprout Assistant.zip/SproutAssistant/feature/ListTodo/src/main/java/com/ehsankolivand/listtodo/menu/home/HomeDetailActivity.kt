package com.ehsankolivand.listtodo.menu.home

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.ehsankolivand.listtodo.R
import com.ehsankolivand.listtodo.adapter.HomeDetailAdapter
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator
import dagger.hilt.android.AndroidEntryPoint
import java.lang.Exception
import java.util.ArrayList

@AndroidEntryPoint
class HomeDetailActivity : AppCompatActivity() {
     lateinit var buttonBack: ImageButton
     val imagesList: MutableList<Int> = ArrayList()
     lateinit var viewPager: ViewPager
     lateinit var adapter: HomeDetailAdapter
     lateinit var dotsIndicator: WormDotsIndicator

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideStatusBar()
        setContentView(R.layout.activity_home_detail)
        setViews()
        initViews()
        initData()
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun hideStatusBar() {
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                window.decorView.systemUiVisibility = 3328
            } else {
                requestWindowFeature(Window.FEATURE_NO_TITLE)
                window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setViews() {
        buttonBack = findViewById(R.id.button_back)
        viewPager = findViewById(R.id.view_pager)
    }

    private fun initViews() {
        buttonBack!!.setOnClickListener { view: View? -> onBackPressed() }
    }

    private fun initData() {
        /**Add Images List */
        imagesList.add(R.drawable.detail_home_picture)
        imagesList.add(R.drawable.detail_home_picture)
        imagesList.add(R.drawable.detail_home_picture)
        imagesList.add(R.drawable.detail_home_picture)
        imagesList.add(R.drawable.detail_home_picture)
        adapter = HomeDetailAdapter(applicationContext, layoutInflater, imagesList)
        viewPager!!.adapter = adapter
        dotsIndicator = findViewById(R.id.layout_dot)
        dotsIndicator.setViewPager(viewPager!!)
        adapter!!.notifyDataSetChanged()
    }
}