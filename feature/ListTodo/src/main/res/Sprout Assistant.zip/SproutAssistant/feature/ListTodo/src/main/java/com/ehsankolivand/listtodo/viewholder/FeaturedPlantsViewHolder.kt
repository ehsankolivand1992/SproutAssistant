package com.ehsankolivand.listtodo.viewholder

import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ehsankolivand.listtodo.R

class FeaturedPlantsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    var featured_plants_picture: ImageView
    var featured_plants_parent: RelativeLayout
    var featured_plants_title: TextView
    var featured_plants_country: TextView
    var featured_plants_price: TextView

    init {
        featured_plants_picture = itemView.findViewById(R.id.item_featured_plants_picture)
        featured_plants_parent = itemView.findViewById(R.id.item_featured_plants_parent)
        featured_plants_title = itemView.findViewById(R.id.item_featured_plants_title)
        featured_plants_country = itemView.findViewById(R.id.item_featured_plants_country)
        featured_plants_price = itemView.findViewById(R.id.item_featured_plants_price)
    }
}
