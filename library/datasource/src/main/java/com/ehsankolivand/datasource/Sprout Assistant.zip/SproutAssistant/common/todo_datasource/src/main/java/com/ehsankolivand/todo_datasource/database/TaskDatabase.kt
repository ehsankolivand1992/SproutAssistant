package com.ehsankolivand.todo_datasource.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.ehsankolivand.todo_datasource.Daos.TaskDao
import com.ehsankolivand.todo_datasource.entity.TaskDatabaseEntity


@Database(entities = [TaskDatabaseEntity::class], version = 1)
internal abstract class TaskDatabase:RoomDatabase() {

    abstract fun taskDao():TaskDao

    companion object{


    }
}